package OpenSource;

import javax.swing.JFrame;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class BrickTest extends JFrame implements KeyListener, ActionListener{

	JLabel scoreLbl;
	private JPanel wholeGame;
	private Rectangle[] brick = new Rectangle[40];
	private JScrollPane p;
	private int Score = 0;
	private static final int BOX_WIDTH = 800; // ��ü ��
	private static final int BOX_HEIGHT = 1300; // ��ü ����
	private float ballRadius = 13; // ���� ������
	private float ballX = BOX_WIDTH/2; // ���� �ʱ� X��ġ
	private float ballY = BOX_HEIGHT - ballRadius; // ���� �ʱ� Y��ġ
	private float ballBoxWidth = 200;
	private float ballBoxHeight = 150;
	private float ballBoxX = 20;
	private float ballBoxY = BOX_HEIGHT - ballBoxHeight;
	private float ballSpeedX = 2;
	private float ballSpeedY = 5; // ���� Y�ӵ�
	private float ballAccel = (float)0.153;
	private boolean left = false;
	private boolean right = false;
	private boolean printMessage = true;
	private boolean isPlay = true; // �÷����Ұ�����
	private boolean dispose = false;
	private int changedPos = BOX_HEIGHT;
	public BrickTest() {
		super();
		setSize(BOX_WIDTH + 26, 1440);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout());
		
		wholeGame = new JPanel() {
				/**
			 * 
			 */
			public void paintComponent(Graphics g) {
				g.setColor(new Color(232, 180, 192));
				g.fillRect(0, 0, BOX_WIDTH, BOX_HEIGHT);
				g.setColor(Color.GREEN);
					
				for(int i = 0; i < 18; i++) {
					g.fillRect((int)brick[i].getX(), (int)brick[i].getY(), (int)brick[i].getWidth(), (int)brick[i].getHeight());
				}		
				g.setColor(Color.RED); // ���������� ä��
				g.fillOval((int) (ballX - ballRadius), (int) (ballY - ballRadius),
						(int) (2 * ballRadius), (int) (2 * ballRadius)); // ��
			}
			
			private static final long serialVersionUID = 1L;

				/*@Override
				public Dimension getPreferredSize() { 
					return new Dimension(800, 900);
				}*/
		};
		
		//wholeGame.setSize(BOX_WIDTH, 900);
		wholeGame.setBackground(new Color(232, 180, 192));
		wholeGame.addKeyListener(this);
		wholeGame.setFocusable(true);
		wholeGame.setFocusTraversalKeysEnabled(false);
		
		p = new JScrollPane(wholeGame);
		p.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		p.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		disableArrowKeys(p.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT));
		
		JPanel scorePnl = new JPanel(); 							//���� �� ǥ�õǴ� ������.
		scorePnl.setLayout(new BorderLayout());						//
		scoreLbl = new JLabel("Score : 0");					//
		scoreLbl.setOpaque(true);									//
		scoreLbl.setBackground(new Color(232, 180, 192));			//
		scoreLbl.setFont(new Font("Monospaced", Font.BOLD, 30));	//
		scoreLbl.setForeground(Color.BLACK);						//
		scoreLbl.setHorizontalAlignment(JLabel.RIGHT);				//
		scorePnl.add(scoreLbl, BorderLayout.CENTER);				//
		add(scorePnl, BorderLayout.NORTH);
		
		resetScrollPos();
		add(wholeGame, BorderLayout.CENTER);
		
		allocateBricks();
		Thread t = new MyThread(); // ������ ��ü ����
		t.start(); // ������ ����
		
	}
	
	private void resetScrollPos() {
		JViewport my = p.getViewport();
		Point a = my.getViewPosition();
		a.x = BOX_WIDTH/2;
		a.y = BOX_WIDTH;
		my.setViewPosition(a);
		p.setViewport(my);
	}
	
	private void changeScore() {
		scoreLbl.setText("Score : " + Score);
	}
	/*
	private void changeScrollVert(float speed) {
		JViewport my = p.getViewport();
		Point a = my.getViewPosition();	
		a.y -= speed;
		changedPos = a.y;
		my.setViewPosition(a);
		p.setViewport(my);
		return;
	}
	
	private void changeScrollHori(float speed) {
		JViewport my = p.getViewport();
		Point a = my.getViewPosition();
		if(a.x > 0) {
			a.x += speed;
			my.setViewPosition(a);
			p.setViewport(my);
			return;
		}
	}
	*/
	public void allocateBricks() {              				// block�� �������� ����
		
		int hSum = BOX_HEIGHT;
		brick[0] = new Rectangle(300, hSum - 70, 140, 20);
		for(int i = 1; i< 18 ; i++) {
			Random random = new Random();
			int rNum = random.nextInt(300);
			if(rNum % 3 == 0) {
				if(brick[i-1].getX() == 530) {
					brick[i] = new Rectangle((int)(brick[i-1].getX() - 230), (hSum - 70*(i+1)), 140, 20);
				}
				else {
					if(brick[i-1].getX() != 70) {
						brick[i] = new Rectangle(70, (hSum - 70*(i+1)), 140, 20);	
					}
					else
						brick[i] = new Rectangle(300, (BOX_HEIGHT - 70*(i+1)), 140, 20);
				}
			}
			else if(rNum % 3 == 1) {
				if(brick[i-1].getX() != 300) {
					brick[i] = new Rectangle(300, (BOX_HEIGHT - 70*(i+1)), 140, 20);
				}
				else {
					if(rNum % 2 == 0)
						brick[i] = new Rectangle(70, (BOX_HEIGHT - 70*(i+1)), 140, 20);
					else
						brick[i] = new Rectangle(530, (BOX_HEIGHT - 70*(i+1)), 140, 20);
				}
			}
			else {
				if(brick[i-1].getX() == 70) {
					brick[i] = new Rectangle((int)(brick[i-1].getX() + 230), (hSum - 70*(i+1)), 140, 20);
				}
				else {
					if(brick[i-1].getX() != 530)
						brick[i] = new Rectangle(530, (BOX_HEIGHT - 70*(i+1)), 140, 20);
					else
						brick[i] = new Rectangle(300, (BOX_HEIGHT - 70*(i+1)), 140, 20);
				}
			}
		}	

	}
	
	public void isVisible(boolean val) {
		setVisible(val);
	}
	
	/*public void paintComponent(Graphics g) {
		g.setColor(new Color(232, 180, 192));
		g.fillRect(0, 0, BOX_WIDTH, BOX_HEIGHT);
		g.setColor(Color.GREEN);
			
		for(int i = 0; i < 10; i++) {
			if(i % 2 == 0) {
			//	brick[i] = new Rectangle(70, (330 + 60*i), 140, 20);
				g.fillRect((int)brick[i].getX(), (int)brick[i].getY(), (int)brick[i].getWidth(), (int)brick[i].getHeight());
			}
			else {
			//	brick[i] = new Rectangle(300, (330 + 60*i), 140, 20);
				g.fillRect((int)brick[i].getX(), (int)brick[i].getY(), (int)brick[i].getWidth(), (int)brick[i].getHeight());
			}
		}		
		g.setColor(Color.RED); // ���������� ä��
		g.fillOval((int) (ballX - ballRadius), (int) (ballY - ballRadius),
				(int) (2 * ballRadius), (int) (2 * ballRadius)); // ��
	}
	*/

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String btn = e.getActionCommand();
	}

	class MyThread extends Thread {
		public void run() { 	// �����Ͽ��� �ϴ� �۾��� ������
			while (true) {
				if(dispose)
					dispose();
				checkEnd();
				if(isPlay) {
					ballY += ballSpeedY;
					if(ballSpeedY < 0) {
						if(ballSpeedY < -5) 
							ballSpeedY = -5;
						else {
							ballSpeedY = ballSpeedY + ballAccel;
						}
					}
					if(ballSpeedY > 0) {                             //���ӵ� ȿ�� 5�� 0.153�� ����
						if(ballSpeedY > 5)                            
							ballSpeedY = 5;
						else
							ballSpeedY = ballSpeedY + ballAccel;
					}
					
					calBallBox();
					if (left == true) {
						ballX -= ballSpeedX;
					    right = false;
					}
					if (right == true) {
					    ballX += ballSpeedX;
					    left = false;
					}
					if(ballY - ballRadius < brick[17].getY() -70) {  // ���� ball box�� õ�忡 ������
						ballSpeedY = -ballSpeedY;
						//ballY = ballBoxY + ballRadius;
					} else if (ballY + ballRadius > ballBoxY + ballBoxHeight) { // ���� ball box�� �ٴڿ� ������
						ballSpeedY = -ballSpeedY;
						ballY = ballBoxY + ballBoxHeight - ballRadius;
					}
				}
				if (isPlay) { // isPlay ������ true�̸�
					repaint(); // �׸���.
				}
				try {
					Thread.sleep(15); // ���� �ӵ� ����
				} catch (InterruptedException ex) {
				}
			}
		}
	}
	
	protected void checkEnd() {
		int tempScore;
		tempScore = Score;
		if(Score > 0) {
			if((ballY + ballRadius) == BOX_HEIGHT) {
				Score = 0;
				isPlay = false;
				EndMessage gui = new EndMessage();
				gui.setVisible(true);
			}
				
		}
	}
	
	protected int printScore() {
		return Score;
	}
	
	private class EndMessage extends JFrame implements ActionListener{

		public EndMessage() {
			super("Game Over");
			setSize(500, 200);
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setLayout(new GridLayout(1, 2));
			
			JButton reStart, end;
			reStart = new JButton("restart");
			reStart.addActionListener(this);
			reStart.setActionCommand("restart");
			reStart.setFont(new Font("SansSerif", Font.BOLD + Font.ITALIC, 30));
			reStart.setText("RESTART");
			end = new JButton("end");
			end.addActionListener(this);
			end.setActionCommand("end");
			end.setFont(new Font("SansSerif", Font.BOLD + Font.ITALIC, 30));
			end.setText("END");
			
			add(reStart);
			add(end);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			String cmd = e.getActionCommand();
			if(cmd.equals("restart")) {
				changeScore();
				isPlay = true;
				dispose();
			}
			else if(cmd.equals("end")) {
				dispose = true;
				dispose();
			}
		}
		
	}
	
	protected void calBallBox() {// ���� �ٿ� ��Ҵ��� Ȯ��
		Rectangle tempBall = new Rectangle((int)(ballX - ballRadius), (int)(ballY - ballRadius), (int)(ballRadius*2), (int)(ballRadius*2));
		//Rectangle halfRBall = new Rectangle((int)(ballX), (int)(ballY - ballRadius), (int)(ballRadius), (int)(ballRadius*2));
		//Rectangle halfLBall = new Rectangle((int)(ballX - ballRadius), (int)(ballY - ballRadius), (int)(ballRadius), (int)(ballRadius*2));
		int brickNum = -1; //���Ʒ� �˻�
	//	int RbrickNum = -1; //���� �˻�
	//	int LbrickNum = -1; //������ �˻�
		//float tempBallX, tempBallY;
		for(int i = 0; i < 18; i++) {
			if(brick[i].intersects(tempBall)) { 
				brickNum = i;
				break;
			}
		}
		
		if(ballSpeedY < 0) {
			if(brickNum != -1) 
				ballSpeedY = -ballSpeedY;
			return;
		}
		
		if(ballSpeedY > 0) {
			if(brickNum != -1) {		
				ballBoxY = (float) (brick[brickNum].getY() - ballBoxHeight);
				ballSpeedY = 5;
				if(ballBoxY + ballBoxHeight == brick[17].getY()) {
					if(printMessage) {
						System.out.println("Congratulation!");
						printMessage = false;
					}
				}
				if((BOX_HEIGHT - brick[brickNum].getY()) > Score) {
					Score = (int)(BOX_HEIGHT - brick[brickNum].getY());
					changeScore();
					System.out.println(Score);
				}
			}
			
			if(brickNum < 0 && ((ballY + ballRadius) < BOX_HEIGHT)) {
				if(ballBoxY < (BOX_HEIGHT - ballBoxHeight))
					ballBoxY += ballSpeedY;
				
				else
					ballBoxY = BOX_HEIGHT - ballBoxHeight;
				
			}
			
			return;
		}
		
	}
	
	@Override
	 public void keyPressed(KeyEvent e) {
	  int keyCode = e.getKeyCode();
	  if (keyCode == KeyEvent.VK_LEFT) {
	   left = true;
	   // System.out.print("left");
	  }

	  if (keyCode == KeyEvent.VK_RIGHT) {
	   right = true;
	   // System.out.print("right");
	  }
	 }

	 @Override
	 public void keyReleased(KeyEvent e) {
	  int keyCode = e.getKeyCode();
	  if (keyCode == KeyEvent.VK_LEFT) {
	   left = false;
	  }

	  if (keyCode == KeyEvent.VK_RIGHT) {
	   right = false;
	  }
	 }

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	static void disableArrowKeys(InputMap im) {
		String[] keystrokeNames = {"UP","DOWN","LEFT","RIGHT"};
		for(int i=0; i<keystrokeNames.length; ++i)
		im.put(KeyStroke.getKeyStroke(keystrokeNames[i]), "none");
		}
}
