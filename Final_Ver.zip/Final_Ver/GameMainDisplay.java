package OpenSource;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;

public class GameMainDisplay extends JFrame implements ActionListener{
	private int WIDTH = 600;
	private int HEIGHT = 700;
	private int score;
	private JLabel bestScore;
	private JLabel title, startBtnLabel;
	private JPanel centerPnl, btnPnl, gifPnl, titlePnl;
	private JButton startBtn;
	private BrickTest game;
	
	public GameMainDisplay() {
		super("BounceToTop!");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		titlePnl = new ImagePanel();
		title = new JLabel("-BOUNCE TO TOP-");
		title.setForeground(Color.CYAN);
		title.setFont(new Font("Monospaced", Font.ITALIC + Font.BOLD, 50));
		title.setHorizontalAlignment(JLabel.CENTER);
		
		titlePnl.add(title, BorderLayout.CENTER);
		add(titlePnl, BorderLayout.NORTH);
		
		centerPnl = new ImagePanel();
		centerPnl.setLayout(null);		
		startBtn = new JButton();
		startBtn.setActionCommand("Start");
		startBtn.setBackground(Color.BLACK);
		startBtn.addActionListener(this);
		startBtn.setLayout(new BorderLayout());
		startBtn.setBounds(190, 225, 200, 100);
		startBtnLabel = new JLabel();
		startBtnLabel.setText("START");
		startBtnLabel.setForeground(Color.WHITE);
		startBtnLabel.setHorizontalAlignment(JLabel.CENTER);
		startBtnLabel.setFont(new Font("Monospaced", Font.BOLD, 40));
		startBtn.add(startBtnLabel, BorderLayout.CENTER);
		centerPnl.add(startBtn);
		
		//btnPnl = new JPanel();
		//btnPnl.setLayout(new FlowLayout());
		
		add(centerPnl, BorderLayout.CENTER);
		
		
		bestScore = new JLabel("Best Score : 0");
		bestScore.setForeground(Color.ORANGE);
		bestScore.setFont(new Font("Monospaced", Font.BOLD, 35));
		bestScore.setHorizontalAlignment(JLabel.RIGHT);
		bestScore.setOpaque(true);
		bestScore.setBackground(Color.BLACK);
		 
		//add(bestScore, BorderLayout.SOUTH);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String cmd = e.getActionCommand();
		
		if( cmd.equals("Start")) {
			game = new BrickTest();
			game.setVisible(true);
		}
		
	}
	
	class ImagePanel extends JPanel {

		Image image;
		  public ImagePanel() {
		    image = Toolkit.getDefaultToolkit().createImage("starImg.jpg");
		  }

		  @Override
		  public void paintComponent(Graphics g) {
		    super.paintComponent(g);
		    if (image != null) {
		      g.drawImage(image, 0, 0, this);
		    }
		  }

		}
}
